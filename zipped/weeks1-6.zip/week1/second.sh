#!/bin/bash

# Purpose      : Prints text to the terminal, including user input.
# Filename     : second.sh
# Date Created : 14-Jul-23
# Date Modified: 02-Aug-23
# Author       : Joe Velardi


echo "Hi there!"

echo "It's good to see you $1!"

exit 0

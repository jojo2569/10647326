ECU: CYB6004.1 Cyber Security: Scripting Languages

Preface
This script is designed to pull data from a site containing a list of PWNED Websites, 
showcasing the date of the breach, the number of users impacted, and the category of 
services it also impacted. Navigation will be through a menu system.

How To Use This Application
The application is password protected, with a default password of 'foo-bar'. Upon first
login, once you have enter the password successfully, the system will download data 
from the website and cleanse this data for presentation. The solution is menu driven,
and selection from the menu to display the data in tabular format. There also a
capability of searching the data detail and display the content of the breaches. Lastly,
there is an Administrative sectin that will allow you to refresh the downloaded data, reset
your password, or reset the environment.
#Variables

#WebSite URL
url="https://haveibeenpwned.com/PwnedWebsites"

#Data Files.
dataLocation="../data"
dataSource="../data/PwnedWebsites"
dataCleansed="../data/cleansedData.txt"
dataScratch="../data/tempData.txt"
dataCategory="../data/categoryData.txt"

secretPassword="../data/secret.txt"
defaultPassword="7d89c4f517e3bd4b5e8e76687937005b602ea00c5cba3e25ef1fc6575a55103e  -"

welcomeBanner="../data/banner.txt"
